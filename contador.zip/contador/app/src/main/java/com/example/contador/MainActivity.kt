package com.example.contador

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.contador.ui.theme.ContadorTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ContadorTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Contador(Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun Contador(modifier: Modifier = Modifier) {


    // Estado do contador
    var contador by remember { mutableStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(color = Color(0xFF89FFC2))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Contador😎✌️",
            fontSize = 36.sp,
            color = Color(0xFF4350C5)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Valor atual do contador
        Text(
            text = "Valor: $contador",
            fontSize = 28.sp,
            color = Color.Black
        )

        Spacer(
            modifier = Modifier.height(24.dp))

        // Botão para adicionar (+1)
        Button(onClick = { contador++ }) {
            Text(text = "Adicionar +1")
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Botão para remover (-1)
        Button(onClick = { contador-- }) {
            Text(text = "Remover -1")
        }
    }
}

