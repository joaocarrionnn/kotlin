package com.example.contador

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF6200EE),
                    secondary = Color(0xFF03DAC6),
                    surface = Color(0xFFFFFBFE),
                    onPrimary = Color.White,
                    onSecondary = Color.Black,
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFFF3EDF7)
                ) {
                    ContadorTrucoApp()
                }
            }
        }
    }
}

@Composable
fun ContadorTrucoApp() {
    var pontosA by remember { mutableStateOf(0) }
    var pontosB by remember { mutableStateOf(0) }

    var vitoriasA by remember { mutableStateOf(0) }
    var vitoriasB by remember { mutableStateOf(0) }

    fun checarVitoria() {
        if (pontosA >= 12) {
            vitoriasA++
            pontosA = 0
            pontosB = 0
        } else if (pontosB >= 12) {
            vitoriasB++
            pontosA = 0
            pontosB = 0
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        // Imagem com efeito moderno
        Image(
            painter = painterResource(id = R.drawable.download),
            contentDescription = "Imagem do truco",
            modifier = Modifier
                .height(200.dp)
                .width(300.dp)
                .clip(RoundedCornerShape(16.dp))

        )

        Text(
            text = "CONTADOR DE TRUCO",
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp),
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TimeCard(
                nome = "TIME A",
                pontos = pontosA,
                vitorias = vitoriasA,
                gradientColors = listOf(Color(0xFF6200EE), Color(0xFF3700B3)),
                onAdd = {
                    pontosA++
                    checarVitoria()
                }
            )

            TimeCard(
                nome = "TIME B",
                pontos = pontosB,
                vitorias = vitoriasB,
                gradientColors = listOf(Color(0xFF03DAC6), Color(0xFF018786)),
                onAdd = {
                    pontosB++
                    checarVitoria()
                }
            )
        }

        Button(
            onClick = {
                pontosA = 0
                pontosB = 0
                vitoriasA = 0
                vitoriasB = 0
            },
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFE53935),
                contentColor = Color.White
            ),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 8.dp,
                pressedElevation = 4.dp
            )
        ) {
            Text("RESETAR TUDO", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun TimeCard(
    nome: String,
    pontos: Int,
    vitorias: Int,
    gradientColors: List<Color>,
    onAdd: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(150.dp)
            .shadow(elevation = 12.dp, shape = RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = gradientColors
                )
            )
            .padding(16.dp)
    ) {
        Text(
            nome,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Text(
            "PONTOS",
            fontSize = 14.sp,
            color = Color.White.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
        Text(
            pontos.toString(),
            fontSize = 36.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Text(
            "VITÓRIAS",
            fontSize = 14.sp,
            color = Color.White.copy(alpha = 0.8f),
            textAlign = TextAlign.Center
        )
        Text(
            vitorias.toString(),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        Button(
            onClick = onAdd,
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = gradientColors.first()
            ),
            shape = RoundedCornerShape(50),
            elevation = ButtonDefaults.buttonElevation(
                defaultElevation = 4.dp,
                pressedElevation = 2.dp
            )
        ) {
            Text("+1 PONTO", fontWeight = FontWeight.Bold)
        }
    }
}